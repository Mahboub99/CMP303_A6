#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

void main()
{
	  while(1){}
}

